﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;
using System.Configuration;
using System.Data.SqlClient;

namespace StoreApp.DAL.DB
{
    public class DBRatingDAL : IRatingDAL
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;

        public double GetAverageRating(Guid fileID)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                double result = 0;
                var command = new SqlCommand(@"
                    SELECT AVG(rating) as average FROM dbo.Ratings 
                    WHERE fileID = @fileID
                    GROUP BY fileID;
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@fileID", fileID);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = double.Parse(reader["average"].ToString());
                }

                return result;
            }
        }

        public int GetRating(Guid fileID, Guid userID)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                int result = 0;
                var command = new SqlCommand("SELECT rating FROM dbo.Ratings WHERE fileID = @fileID AND userID = @userID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@fileID", fileID);
                command.Parameters.AddWithValue("@userID", userID);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = int.Parse(reader["rating"].ToString());
                }

                return result;
            }
        }

        public bool SetRating(Guid fileID, Guid userID, int rating)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                    MERGE INTO dbo.Ratings trg
                    USING (SELECT @fileID as fileID, @userID as userID, @rating as rating) src
                        ON (trg.userID = src.userID AND trg.fileID = src.fileID)
                    WHEN MATCHED THEN 
                        UPDATE SET trg.rating = src.rating
                    WHEN NOT MATCHED THEN 
                        INSERT (fileID, userID, rating)
                        VALUES (src.fileID, src.userID, src.rating);
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@fileID", fileID);
                command.Parameters.AddWithValue("@userID", userID);
                command.Parameters.AddWithValue("@rating", rating);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }
    }
}
