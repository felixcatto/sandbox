﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;
using System.Configuration;
using System.Data.SqlClient;

namespace StoreApp.DAL.DB
{
    public class DBAudioFileDAL : IAudioFileDAL
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;

        public bool AddFile(AudioFileDTO file)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("INSERT INTO dbo.AudioFiles (ID, type, name, path, userID) VALUES (@ID, @type, @name, @path, @userID)");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", file.ID);
                command.Parameters.AddWithValue("@type", file.Type);
                command.Parameters.AddWithValue("@name", file.Name);
                command.Parameters.AddWithValue("@path", file.Path);
                command.Parameters.AddWithValue("@userID", file.UserID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public bool DeleteFile(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("DELETE FROM dbo.AudioFiles WHERE ID = @ID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public List<AudioFileDTO> GetAllFiles()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<AudioFileDTO>();
                var command = new SqlCommand("SELECT ID, type, name, path, userID FROM dbo.AudioFiles");
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new AudioFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public AudioFileDTO GetFile(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                AudioFileDTO result = null;
                var command = new SqlCommand("SELECT ID, type, name, path, userID FROM dbo.AudioFiles WHERE ID = @ID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = new AudioFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    };
                }

                if (result == null)
                {
                    throw new ArgumentException("file not exist");
                }

                return result;
            }
        }

        public List<AudioFileDTO> GetFilesByAuthor(string query)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<AudioFileDTO>();
                var command = new SqlCommand(@"
                    SELECT tf.ID, tf.type, tf.name, tf.path, tf.userID 
                    FROM dbo.AudioFiles tf
                    JOIN dbo.SysUsersss su
                        ON tf.userID = su.ID
                    WHERE
                        su.login LIKE @query
                    ORDER BY su.login
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@query", string.Format("%{0}%", query));
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new AudioFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public List<AudioFileDTO> GetFilesByName(string query)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<AudioFileDTO>();
                var command = new SqlCommand(@"
                    SELECT ID, type, name, path, userID 
                    FROM dbo.AudioFiles
                    WHERE
                        name LIKE @query
                    ORDER BY name
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@query", string.Format("%{0}%", query));
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new AudioFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public bool UpdateFile(Guid storedFileID, AudioFileDTO newFile)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                    UPDATE dbo.AudioFiles
                    SET 
                        type = @type,
                        name = @name,
                        path = @path,
                        userID = @userID
                    WHERE
                        ID = @ID
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", storedFileID);
                command.Parameters.AddWithValue("@type", newFile.Type);
                command.Parameters.AddWithValue("@name", newFile.Name);
                command.Parameters.AddWithValue("@path", newFile.Path);
                command.Parameters.AddWithValue("@userID", newFile.UserID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }
    }
}
