﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;

namespace StoreApp.DAL.DB
{
    public class DBSecurityDAL : ISecurityDAL
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;

        public bool AddRoleToUser(SysUserDTO user, SysRoleDTO role)
        {
            return this.InsertUserRoleLink(user.ID, role.ID);
        }

        public bool DeleteUserRoleLink(Guid userID, int roleID)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                    DELETE FROM dbo.SysUsers_SysRoles
                    WHERE SysUserID = @SysUserID
                        AND SysRoleID = @SysRoleID
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@SysUserID", userID);
                command.Parameters.AddWithValue("@SysRoleID", roleID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public string[] GetAllRoles()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var tmp = new List<String>();
                var command = new SqlCommand("SELECT [ID], [RoleName] FROM dbo.Users");
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    tmp.Add((string)reader["RoleName"]);
                }

                var result = new string[tmp.Count];
                for (var i = 0; i < tmp.Count; i++)
                {
                    result[i] = tmp[i];
                }

                return result;
            }
        }

        public List<SysUserDTO> GetAllUsers()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<SysUserDTO>();
                var command = new SqlCommand("SELECT [ID], [Login], [Password] FROM dbo.SysUsersss");
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new SysUserDTO
                    {
                        ID = (Guid)reader["ID"],
                        Login = (string)reader["Login"],
                        Password = (string)reader["Password"],
                    });
                }

                return result;
            }
        }

        public string[] GetRolesForUser(string userName)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var tmp = new List<String>();
                var command = new SqlCommand(@"
                    SELECT [RoleName] FROM dbo.SysUsersss su
                    JOIN dbo.SysUsers_SysRoles susr
                        ON su.ID = susr.SysUserID
                    JOIN dbo.SysRoles sr
                        ON susr.SysRoleID = sr.ID
                    WHERE su.login = @login
                ");
                command.Parameters.AddWithValue("@login", userName);
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    tmp.Add((string)reader["RoleName"]);
                }

                var result = new string[tmp.Count];
                for (var i = 0; i < tmp.Count; i++)
                {
                    result[i] = tmp[i];
                }

                return result;
            }
        }

        public SysUserDTO GetUserByID(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                SysUserDTO result = null;
                var command = new SqlCommand("SELECT [ID], [Login], [Password] FROM dbo.SysUsersss WHERE ID = @id");
                command.Connection = connection;
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = new SysUserDTO
                    {
                        ID = (Guid)reader["ID"],
                        Login = (string)reader["Login"],
                        Password = (string)reader["Password"],
                    };
                }

                if (result == null)
                {
                    throw new ArgumentException("user not exist");
                }

                return result;
            }
        }

        public SysUserDTO GetUserByLogin(string login)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                SysUserDTO result = null;
                var command = new SqlCommand("SELECT [ID], [Login], [Password] FROM dbo.SysUsersss WHERE Login = @Login");
                command.Connection = connection;
                command.Parameters.AddWithValue("@Login", login);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = new SysUserDTO
                    {
                        ID = (Guid)reader["ID"],
                        Login = (string)reader["Login"],
                        Password = (string)reader["Password"],
                    };
                }

                if (result == null)
                {
                    throw new ArgumentException("login not exist");
                }

                return result;
            }
        }

        public bool InsertUserRoleLink(Guid userID, int roleID)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("INSERT INTO dbo.SysUsers_SysRoles (SysUserID, SysRoleID) VALUES (@SysUserID, @SysRoleID)");
                command.Connection = connection;
                command.Parameters.AddWithValue("@SysUserID", userID);
                command.Parameters.AddWithValue("@SysRoleID", roleID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public bool RegisterUser(SysUserDTO user)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("INSERT INTO dbo.SysUsersss (ID, Login, Password) VALUES (@ID, @Login, @Password)");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", user.ID);
                command.Parameters.AddWithValue("@Login", user.Login);
                command.Parameters.AddWithValue("@Password", user.Password);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public bool RegisterRole(SysRoleDTO newRole)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("INSERT INTO dbo.SysRoles (ID, RoleName) VALUES (@ID, @RoleName)");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", newRole.ID);
                command.Parameters.AddWithValue("@RoleName", newRole.RoleName);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }
    }
}
