﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;
using System.Configuration;
using System.Data.SqlClient;

namespace StoreApp.DAL.DB
{
    public class DBVideoFileDAL : IVideoFileDAL
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;

        public bool AddFile(VideoFileDTO file)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("INSERT INTO dbo.VideoFiles (ID, type, name, path, userID) VALUES (@ID, @type, @name, @path, @userID)");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", file.ID);
                command.Parameters.AddWithValue("@type", file.Type);
                command.Parameters.AddWithValue("@name", file.Name);
                command.Parameters.AddWithValue("@path", file.Path);
                command.Parameters.AddWithValue("@userID", file.UserID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public bool DeleteFile(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("DELETE FROM dbo.VideoFiles WHERE ID = @ID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public List<VideoFileDTO> GetAllFiles()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<VideoFileDTO>();
                var command = new SqlCommand("SELECT ID, type, name, path, userID FROM dbo.VideoFiles");
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new VideoFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public VideoFileDTO GetFile(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                VideoFileDTO result = null;
                var command = new SqlCommand("SELECT ID, type, name, path, userID FROM dbo.VideoFiles WHERE ID = @ID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = new VideoFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    };
                }

                if (result == null)
                {
                    throw new ArgumentException("file not exist");
                }

                return result;
            }
        }

        public List<VideoFileDTO> GetFilesByAuthor(string query)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<VideoFileDTO>();
                var command = new SqlCommand(@"
                    SELECT tf.ID, tf.type, tf.name, tf.path, tf.userID 
                    FROM dbo.VideoFiles tf
                    JOIN dbo.SysUsersss su
                        ON tf.userID = su.ID
                    WHERE
                        su.login LIKE @query
                    ORDER BY su.login
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@query", string.Format("%{0}%", query));
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new VideoFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public List<VideoFileDTO> GetFilesByName(string query)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<VideoFileDTO>();
                var command = new SqlCommand(@"
                    SELECT ID, type, name, path, userID 
                    FROM dbo.VideoFiles
                    WHERE
                        name LIKE @query
                    ORDER BY name
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@query", string.Format("%{0}%", query));
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new VideoFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Path = (string)reader["path"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public bool UpdateFile(Guid storedFileID, VideoFileDTO newFile)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                    UPDATE dbo.VideoFiles
                    SET 
                        type = @type,
                        name = @name,
                        path = @path,
                        userID = @userID
                    WHERE
                        ID = @ID
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", storedFileID);
                command.Parameters.AddWithValue("@type", newFile.Type);
                command.Parameters.AddWithValue("@name", newFile.Name);
                command.Parameters.AddWithValue("@path", newFile.Path);
                command.Parameters.AddWithValue("@userID", newFile.UserID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }
    }
}
