﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;
using System.Configuration;
using System.Data.SqlClient;

namespace StoreApp.DAL.DB
{
    public class DBTextFileDAL : ITextFileDAL
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;

        public bool AddFile(TextFileDTO file)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("INSERT INTO dbo.TextFiles (ID, type, name, data, userID) VALUES (@ID, @type, @name, @data, @userID)");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", file.ID);
                command.Parameters.AddWithValue("@type", file.Type);
                command.Parameters.AddWithValue("@name", file.Name);
                command.Parameters.AddWithValue("@data", file.Data);
                command.Parameters.AddWithValue("@userID", file.UserID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public bool DeleteFile(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("DELETE FROM dbo.TextFiles WHERE ID = @ID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }

        public List<TextFileDTO> GetAllFiles()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<TextFileDTO>();
                var command = new SqlCommand("SELECT ID, type, name, data, userID FROM dbo.TextFiles");
                command.Connection = connection;
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new TextFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Data = (string)reader["data"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public TextFileDTO GetFile(Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                TextFileDTO result = null;
                var command = new SqlCommand("SELECT ID, type, name, data, userID FROM dbo.TextFiles WHERE ID = @ID");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", id);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result = new TextFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Data = (string)reader["data"],
                        UserID = (Guid)reader["userID"],
                    };
                }

                if (result == null)
                {
                    throw new ArgumentException("file not exist");
                }

                return result;
            }
        }

        public List<TextFileDTO> GetFilesByAuthor(string query)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<TextFileDTO>();
                var command = new SqlCommand(@"
                    SELECT tf.ID, tf.type, tf.name, tf.data, tf.userID 
                    FROM dbo.TextFiles tf
                    JOIN dbo.SysUsersss su
                        ON tf.userID = su.ID
                    WHERE
                        su.login LIKE @query
                    ORDER BY su.login
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@query", string.Format("%{0}%", query));
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new TextFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Data = (string)reader["data"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public List<TextFileDTO> GetFilesByName(string query)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var result = new List<TextFileDTO>();
                var command = new SqlCommand(@"
                    SELECT ID, type, name, data, userID 
                    FROM dbo.TextFiles
                    WHERE
                        name LIKE @query
                    ORDER BY name
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@query", string.Format("%{0}%", query));
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    result.Add(new TextFileDTO
                    {
                        ID = (Guid)reader["ID"],
                        Type = (string)reader["type"],
                        Name = (string)reader["name"],
                        Data = (string)reader["data"],
                        UserID = (Guid)reader["userID"],
                    });
                }

                return result;
            }
        }

        public bool UpdateFile(Guid storedFileID, TextFileDTO newFile)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                    UPDATE dbo.TextFiles
                    SET 
                        type = @type,
                        name = @name,
                        data = @data,
                        userID = @userID
                    WHERE
                        ID = @ID
                ");
                command.Connection = connection;
                command.Parameters.AddWithValue("@ID", storedFileID);
                command.Parameters.AddWithValue("@type", newFile.Type);
                command.Parameters.AddWithValue("@name", newFile.Name);
                command.Parameters.AddWithValue("@data", newFile.Data);
                command.Parameters.AddWithValue("@userID", newFile.UserID);
                connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
        }
    }
}
