﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.BLL.Abstract;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;

namespace StoreApp.BLL.Logic
{
    public class TextFileLogic : ITextFileBLL
    {
        private ITextFileDAL DAL;

        public TextFileLogic(ITextFileDAL dal)
        {
            if (dal == null)
            {
                throw new ArgumentNullException("DAL must be not null");
            }

            this.DAL = dal;
        }

        public bool AddFile(TextFileDTO file)
        {
            return this.DAL.AddFile(file);
        }

        public bool DeleteFile(Guid id)
        {
            return this.DAL.DeleteFile(id);
        }

        public List<TextFileDTO> GetAllFiles()
        {
            return this.DAL.GetAllFiles();
        }

        public TextFileDTO GetFile(Guid id)
        {
            return this.DAL.GetFile(id);
        }

        public List<TextFileDTO> GetFilesByAuthor(string query)
        {
            return this.DAL.GetFilesByAuthor(query);
        }

        public List<TextFileDTO> GetFilesByName(string query)
        {
            return this.DAL.GetFilesByName(query);
        }

        public bool UpdateFile(Guid storedFileID, TextFileDTO newFile)
        {
            return this.DAL.UpdateFile(storedFileID, newFile);
        }
    }
}
