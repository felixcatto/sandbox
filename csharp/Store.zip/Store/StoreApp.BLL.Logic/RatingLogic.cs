﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.BLL.Abstract;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;

namespace StoreApp.BLL.Logic
{
    public class RatingLogic : IRatingBLL
    {
        private IRatingDAL DAL;

        public RatingLogic(IRatingDAL dal)
        {
            if (dal == null)
            {
                throw new ArgumentNullException("DAL must be not null");
            }

            this.DAL = dal;
        }

        public double GetAverageRating(Guid fileID)
        {
            return this.DAL.GetAverageRating(fileID);
        }

        public int GetRating(Guid fileID, Guid userID)
        {
            return this.DAL.GetRating(fileID, userID);
        }

        public bool SetRating(Guid fileID, Guid userID, int rating)
        {
            return this.DAL.SetRating(fileID, userID, rating);
        }
    }
}
