﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.BLL.Abstract;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;

namespace StoreApp.BLL.Logic
{
    public class VideoFileLogic : IVideoFileBLL
    {
        private IVideoFileDAL DAL;

        public VideoFileLogic(IVideoFileDAL dal)
        {
            if (dal == null)
            {
                throw new ArgumentNullException("DAL must be not null");
            }

            this.DAL = dal;
        }

        public bool AddFile(VideoFileDTO file)
        {
            return this.DAL.AddFile(file);
        }

        public bool DeleteFile(Guid id)
        {
            return this.DAL.DeleteFile(id);
        }

        public List<VideoFileDTO> GetAllFiles()
        {
            return this.DAL.GetAllFiles();
        }

        public VideoFileDTO GetFile(Guid id)
        {
            return this.DAL.GetFile(id);
        }

        public List<VideoFileDTO> GetFilesByAuthor(string query)
        {
            return this.DAL.GetFilesByAuthor(query);
        }

        public List<VideoFileDTO> GetFilesByName(string query)
        {
            return this.DAL.GetFilesByName(query);
        }

        public bool UpdateFile(Guid storedFileID, VideoFileDTO newFile)
        {
            return this.DAL.UpdateFile(storedFileID, newFile);
        }
    }
}
