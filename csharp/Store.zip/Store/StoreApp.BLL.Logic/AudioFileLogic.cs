﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.BLL.Abstract;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;

namespace StoreApp.BLL.Logic
{
    public class AudioFileLogic : IAudioFileBLL
    {
        private IAudioFileDAL DAL;

        public AudioFileLogic(IAudioFileDAL dal)
        {
            if (dal == null)
            {
                throw new ArgumentNullException("DAL must be not null");
            }

            this.DAL = dal;
        }

        public bool AddFile(AudioFileDTO file)
        {
            return this.DAL.AddFile(file);
        }

        public bool DeleteFile(Guid id)
        {
            return this.DAL.DeleteFile(id);
        }

        public List<AudioFileDTO> GetAllFiles()
        {
            return this.DAL.GetAllFiles();
        }

        public AudioFileDTO GetFile(Guid id)
        {
            return this.DAL.GetFile(id);
        }

        public List<AudioFileDTO> GetFilesByAuthor(string query)
        {
            return this.DAL.GetFilesByAuthor(query);
        }

        public List<AudioFileDTO> GetFilesByName(string query)
        {
            return this.DAL.GetFilesByName(query);
        }

        public bool UpdateFile(Guid storedFileID, AudioFileDTO newFile)
        {
            return this.DAL.UpdateFile(storedFileID, newFile);
        }
    }
}
