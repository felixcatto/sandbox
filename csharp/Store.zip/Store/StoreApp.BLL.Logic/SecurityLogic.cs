﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.BLL.Abstract;
using StoreApp.DAL.Abstract;
using StoreApp.Entities;

namespace StoreApp.BLL.Logic
{
    public class SecurityLogic : ISecurityBLL
    {
        private ISecurityDAL securityDAL;

        public SecurityLogic(ISecurityDAL securityDAL)
        {
            if (securityDAL == null)
            {
                throw new ArgumentNullException("DAL must be not null");
            }

            this.securityDAL = securityDAL;
        }

        public SysUserDTO GetUserByID(Guid id)
        {
            return this.securityDAL.GetUserByID(id);
        }

        public SysUserDTO GetUserByLogin(string login)
        {
            return this.securityDAL.GetUserByLogin(login);
        }

        public List<SysUserDTO> GetAllUsers()
        {
            return this.securityDAL.GetAllUsers();
        }

        public bool RegisterUser(SysUserDTO user)
        {
            return this.securityDAL.RegisterUser(user);
        }

        public bool RegisterRole(SysRoleDTO role)
        {
            return this.securityDAL.RegisterRole(role);
        }

        public bool AddRoleToUser(SysUserDTO user, SysRoleDTO role)
        {
            return this.securityDAL.AddRoleToUser(user, role);
        }

        public string[] GetAllRoles()
        {
            return this.securityDAL.GetAllRoles();
        }

        public string[] GetRolesForUser(string userName)
        {
            return this.securityDAL.GetRolesForUser(userName);
        }
    }
}