﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreApp.Entities
{
    public class SysRoleDTO
    {
        public int ID { get; set; }

        public string RoleName { get; set; }
    }
}
