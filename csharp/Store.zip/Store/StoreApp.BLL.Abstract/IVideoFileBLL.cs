﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.Entities;

namespace StoreApp.BLL.Abstract
{
    public interface IVideoFileBLL
    {
        List<VideoFileDTO> GetAllFiles();

        bool AddFile(VideoFileDTO file);

        VideoFileDTO GetFile(Guid id);

        bool UpdateFile(Guid storedFileID, VideoFileDTO newFile);

        bool DeleteFile(Guid id);

        List<VideoFileDTO> GetFilesByName(string query);

        List<VideoFileDTO> GetFilesByAuthor(string query);
    }
}
