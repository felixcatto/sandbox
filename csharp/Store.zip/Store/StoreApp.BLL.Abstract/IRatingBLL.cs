﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreApp.BLL.Abstract
{
    public interface IRatingBLL
    {
        bool SetRating(Guid fileID, Guid userID, int rating);

        int GetRating(Guid fileID, Guid userID);

        double GetAverageRating(Guid fileID);
    }
}
