﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.Entities;

namespace StoreApp.BLL.Abstract
{
    public interface ITextFileBLL
    {
        List<TextFileDTO> GetAllFiles();

        bool AddFile(TextFileDTO file);

        TextFileDTO GetFile(Guid id);

        bool UpdateFile(Guid storedFileID, TextFileDTO newFile);

        bool DeleteFile(Guid id);

        List<TextFileDTO> GetFilesByName(string query);

        List<TextFileDTO> GetFilesByAuthor(string query);
    }
}
