﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.BLL.Abstract;
using StoreApp.BLL.Logic;
using StoreApp.DAL.Abstract;
using StoreApp.DAL.DB;

namespace StoreApp.DI.Provaiders
{
    public static class Provaider
    {
        static Provaider()
        {
            string typeDAL = ConfigurationManager.AppSettings["TypeDAL"];
            var typeBLL = ConfigurationManager.AppSettings["TypeBLL"].Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            if (typeDAL == "DB")
            {
                TextFileDAL = new DBTextFileDAL();
                TextFileBLL = new TextFileLogic(TextFileDAL);
                AudioFileDAL = new DBAudioFileDAL();
                AudioFileBLL = new AudioFileLogic(AudioFileDAL);
                VideoFileDAL = new DBVideoFileDAL();
                VideoFileBLL = new VideoFileLogic(VideoFileDAL);
                RatingDAL = new DBRatingDAL();
                RatingBLL = new RatingLogic(RatingDAL);
                SecurityDAL = new DBSecurityDAL();
                SecurityBLL = new SecurityLogic(SecurityDAL);
            }
        }

        private static ISecurityDAL SecurityDAL { get; set; }

        private static ITextFileDAL TextFileDAL { get; set; }

        private static IAudioFileDAL AudioFileDAL { get; set; }

        private static IVideoFileDAL VideoFileDAL { get; set; }

        private static IRatingDAL RatingDAL { get; set; }

        public static ISecurityBLL SecurityBLL { get; private set; }

        public static ITextFileBLL TextFileBLL { get; private set; }

        public static IAudioFileBLL AudioFileBLL { get; private set; }

        public static IVideoFileBLL VideoFileBLL { get; private set; }

        public static IRatingBLL RatingBLL { get; private set; }
    }
}
