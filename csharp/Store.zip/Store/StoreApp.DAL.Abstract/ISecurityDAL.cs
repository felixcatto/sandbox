﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.Entities;

namespace StoreApp.DAL.Abstract
{
    public interface ISecurityDAL
    {
        SysUserDTO GetUserByLogin(string login);

        SysUserDTO GetUserByID(Guid id);

        List<SysUserDTO> GetAllUsers();

        bool RegisterUser(SysUserDTO user);

        bool RegisterRole(SysRoleDTO role);

        bool AddRoleToUser(SysUserDTO user, SysRoleDTO role);

        string[] GetAllRoles();

        string[] GetRolesForUser(string userName);

        bool InsertUserRoleLink(Guid userID, int roleID);

        bool DeleteUserRoleLink(Guid userID, int roleID);
    }
}
