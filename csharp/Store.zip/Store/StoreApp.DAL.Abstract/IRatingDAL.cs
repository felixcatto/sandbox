﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreApp.DAL.Abstract
{
    public interface IRatingDAL
    {
        bool SetRating(Guid fileID, Guid userID, int rating);

        int GetRating(Guid fileID, Guid userID);

        double GetAverageRating(Guid fileID);
    }
}
