﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.Entities;

namespace StoreApp.DAL.Abstract
{
    public interface IAudioFileDAL
    {
        List<AudioFileDTO> GetAllFiles();

        bool AddFile(AudioFileDTO file);

        AudioFileDTO GetFile(Guid id);

        bool UpdateFile(Guid storedFileID, AudioFileDTO newFile);

        bool DeleteFile(Guid id);

        List<AudioFileDTO> GetFilesByName(string query);

        List<AudioFileDTO> GetFilesByAuthor(string query);
    }
}
