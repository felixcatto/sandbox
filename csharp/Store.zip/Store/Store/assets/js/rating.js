﻿(function () {
    // INIT
    var root = $('.file__stars'),
        stars = $('i', root),
        rating = +root.attr('data-rating'),
        url = root.attr('data-url'),
        fileID = root.attr('data-id'),
        averageRating = $('.file__av-rating'),
        averageRatingUrl = averageRating.attr('data-url');

    setVisualRating(rating);



    // UTILITY FUNCTIONS
    function setVisualRating(rating) {
        var i;
        for (i = 0; i < rating; i++) {
            stars[i].classList.remove('glyphicon-star-empty');
            stars[i].classList.add('glyphicon-star');
        }

        for (; i < stars.length; i++) {
            stars[i].classList.remove('glyphicon-star');
            stars[i].classList.add('glyphicon-star-empty');
        }
    }

    function updateRating(rating) {
        var star = stars[rating - 1];
        star.classList.add('irotate');
        $.ajax({
            url: url,
            method: "POST",
            data: {
                "rating": rating,
                "fileID": fileID
            }
        }).then(function (data) {
            star.classList.remove('irotate');
            return $.ajax({
                url: averageRatingUrl,
                data: {
                    "fileID": fileID
                }
            });
        }).then(function (data) {
            averageRating.text(+data);
            console.log("done");
        });
    }



    // EVENT LISTENERS
    stars.on('click', function (event) {
        var rating = $(this).index() + 1;
        setVisualRating(rating);
        updateRating(rating);
    });
}());