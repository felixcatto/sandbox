﻿(function () {
    // INIT
    var menuBtn = $('.header-nav__mobile-menu-btn'),
        menu = $('.header-nav__menu');





    // UTILITY FUNCTIONS




    // EVENT LISTENERS
    menuBtn.on('click', function (event) {
        menuBtn.toggleClass('header-nav__mobile-menu-btn_active');
        menu.toggleClass('header-nav__menu_active');
    });
}());