﻿(function () {
    // INIT
    var root = $('.search'),
        mainContainer = $('.js-search-static-content'),
        searchInput = $('.search__input', root),
        criterions = $('.search__criteria input', root),
        searchResultRoot = $('.search-result'),
        searchResultData = $('.search-result__data', searchResultRoot),
        preloader = $('.search-result__preloader', searchResultRoot),
        url = root.attr('data-url'),
        timeout = 1000,
        timeoutID = null;

    preloader.hide();



    // UTILITY FUNCTIONS
    function execSearch(query) {
        var criteria;
        criterions.each(function (i, el) {
            if (this.checked) {
                criteria = this.value;
            }
        });
        $.ajax({
            url: url,
            data: {
                'query': query,
                'criteria': criteria
            }
        }).then(function (data) {
            searchResultData.html(data);
            preloader.hide();
        });
    }



    // EVENT LISTENERS
    searchInput.on('input', function (event) {
        var query = searchInput.val();
        if (query == '') {
            clearTimeout(timeoutID);
            mainContainer.show();
            preloader.hide();
            searchResultData.html('');
        }
        else {
            clearTimeout(timeoutID);
            mainContainer.hide();
            preloader.show();
            timeoutID = setTimeout(function () {
                execSearch(query);
            }, timeout);
        }
    });
}());