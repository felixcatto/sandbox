﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StoreApp.Entities;

namespace StoreApp.PL.WebUI.Models
{
    public class AudioFileVM
    {
        public AudioFileVM(string name, string type, string path, Guid userID)
        {
            this.ID = Guid.NewGuid();
            this.Name = name;
            this.Type = type;
            this.Path = path;
            this.UserID = userID;
        }

        public AudioFileVM(Guid ID, string name, string type, string path, Guid userID)
        {
            this.ID = ID;
            this.Name = name;
            this.Type = type;
            this.Path = path;
            this.UserID = userID;
        }

        private AudioFileVM()
        {
        }

        private string path;

        private string name;

        public Guid ID { get; set; }

        public string Type { get; set; }

        public Guid UserID { get; set; }

        public string Name {
            get
            {
                return this.name;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("name can not be null or empty");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public string Path {
            get
            {
                return this.path;
            }
            set
            {
                if (!value.EndsWith(".mp3"))
                {
                    throw new ArgumentException("accepted only mp3 files");
                }
                else
                {
                    this.path = value;
                }
            }
        }

        public static implicit operator AudioFileDTO(AudioFileVM model)
        {
            return new AudioFileDTO()
            {
                ID = model.ID,
                Name = model.Name,
                Type = model.Type,
                Path = model.Path,
                UserID = model.UserID,
            };
        }

        public static implicit operator AudioFileVM(AudioFileDTO model)
        {
            return new AudioFileVM()
            {
                ID = model.ID,
                Name = model.Name,
                Type = model.Type,
                Path = model.Path,
                UserID = model.UserID,
            };
        }
    }
}