﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.Entities;

namespace StoreApp.PL.WebUI.Models
{
    public class SysUserVM
    {
        public SysUserVM(string login, string password)
        {
            this.ID = Guid.NewGuid();
            this.Login = login;
            this.Password = password;
        }

        private SysUserVM()
        {
        }

        private string login;

        private string password;

        public Guid ID { get; set; }

        public string Login
        {
            get
            {
                return this.login;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    this.login = value;
                }
                else
                {
                    throw new ArgumentException("empty login");
                }
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    this.password = value;
                }
                else
                {
                    throw new ArgumentException("empty password");
                }
            }
        }

        public static implicit operator SysUserDTO(SysUserVM model)
        {
            return new SysUserDTO()
            {
                ID = model.ID,
                Login = model.Login,
                Password = model.Password
            };
        }

        public static implicit operator SysUserVM(SysUserDTO model)
        {
            return new SysUserVM()
            {
                ID = model.ID,
                Login = model.Login,
                Password = model.Password
            };
        }
    }
}
