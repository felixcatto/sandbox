﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreApp.Entities;

namespace StoreApp.PL.WebUI.Models
{
    public class SysRoleVM
    {
        public SysRoleVM(int id, string name)
        {
            this.ID = id;
            this.RoleName = name;
        }

        private SysRoleVM()
        {
        }

        public int ID { get; set; }

        public string RoleName { get; set; }

        public static implicit operator SysRoleDTO(SysRoleVM model)
        {
            return new SysRoleDTO()
            {
                ID = model.ID,
                RoleName = model.RoleName
            };
        }

        public static implicit operator SysRoleVM(SysRoleDTO model)
        {
            return new SysRoleVM()
            {
                ID = model.ID,
                RoleName = model.RoleName
            };
        }
    }
}
