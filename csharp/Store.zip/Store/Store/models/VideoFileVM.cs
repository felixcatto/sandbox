﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StoreApp.Entities;

namespace StoreApp.PL.WebUI.Models
{
    public class VideoFileVM
    {
        public VideoFileVM(string name, string type, string path, Guid userID)
        {
            this.ID = Guid.NewGuid();
            this.Name = name;
            this.Type = type;
            this.Path = path;
            this.UserID = userID;
        }

        public VideoFileVM(Guid ID, string name, string type, string path, Guid userID)
        {
            this.ID = ID;
            this.Name = name;
            this.Type = type;
            this.Path = path;
            this.UserID = userID;
        }

        private VideoFileVM()
        {
        }

        private string path;

        private string name;

        public Guid ID { get; set; }

        public string Type { get; set; }

        public Guid UserID { get; set; }

        public string Name {
            get
            {
                return this.name;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("name can not be null or empty");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public string Path {
            get
            {
                return this.path;
            }
            set
            {
                if (!value.EndsWith(".mp4") && !value.EndsWith(".webm"))
                {
                    throw new ArgumentException("accepted only .mp4 & .webm files");
                }
                else
                {
                    this.path = value;
                }
            }
        }

        public static implicit operator VideoFileDTO(VideoFileVM model)
        {
            return new VideoFileDTO()
            {
                ID = model.ID,
                Name = model.Name,
                Type = model.Type,
                Path = model.Path,
                UserID = model.UserID,
            };
        }

        public static implicit operator VideoFileVM(VideoFileDTO model)
        {
            return new VideoFileVM()
            {
                ID = model.ID,
                Name = model.Name,
                Type = model.Type,
                Path = model.Path,
                UserID = model.UserID,
            };
        }
    }
}