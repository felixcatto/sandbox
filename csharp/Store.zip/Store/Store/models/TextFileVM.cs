﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StoreApp.Entities;

namespace StoreApp.PL.WebUI.Models
{
    public class TextFileVM
    {
        public TextFileVM(string name, string type, string data, Guid userID)
        {
            this.ID = Guid.NewGuid();
            this.Name = name;
            this.Type = type;
            this.Data = data;
            this.UserID = userID;
        }

        private TextFileVM()
        {
        }

        private string data;

        private string name;

        private string type;

        public Guid ID { get; set; }

        public Guid UserID { get; set; }

        public string Type {
            get
            {
                return this.type;
            }
            set
            {
                if (value != "text/plain")
                {
                    throw new ArgumentException("accepted only txt files");
                }
                else
                {
                    this.type = value;
                }
            }
        }        

        public string Name {
            get
            {
                return this.name;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("name can not be null or empty");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public string Data {
            get
            {
                return this.data;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("data can not be null or empty");
                }
                else
                {
                    this.data = value;
                }
            }
        }

        public static implicit operator TextFileDTO(TextFileVM model)
        {
            return new TextFileDTO()
            {
                ID = model.ID,
                Name = model.Name,
                Type = model.Type,
                Data = model.Data,
                UserID = model.UserID,
            };
        }

        public static implicit operator TextFileVM(TextFileDTO model)
        {
            return new TextFileVM()
            {
                ID = model.ID,
                Name = model.Name,
                Type = model.Type,
                Data = model.Data,
                UserID = model.UserID,
            };
        }
    }
}