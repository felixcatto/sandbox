﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using StoreApp.DI.Provaiders;
using StoreApp.PL.WebUI.Models;
using System.Security.Cryptography;
using System.Text;

namespace Store
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            if (Provaider.SecurityBLL.GetAllUsers().Count == 0)
            {
                Provaider.SecurityBLL.RegisterRole(new SysRoleVM(0, "ADMIN"));
                Provaider.SecurityBLL.RegisterRole(new SysRoleVM(1, "USER"));

                var login = "admin";
                var password = "admin";
                var sha1 = new SHA1CryptoServiceProvider();
                var sha1data = sha1.ComputeHash(Encoding.ASCII.GetBytes(password));
                var hashedPassword = new ASCIIEncoding().GetString(sha1data, 0, sha1data.Length);
                var user = new SysUserVM(login, hashedPassword);
                Provaider.SecurityBLL.RegisterUser(user);
                Provaider.SecurityBLL.AddRoleToUser(user, new SysRoleVM(0, "ADMIN"));
                Provaider.SecurityBLL.AddRoleToUser(user, new SysRoleVM(1, "USER"));
            }
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}